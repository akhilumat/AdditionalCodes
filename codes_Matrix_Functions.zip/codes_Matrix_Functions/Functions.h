#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED

void Transpose(float a[30][30], float trans[30][30], int rows, int cols) //Transpose function
{
  for(int i=0;i<rows;i++)
  {
    for(int j=0;j<cols;j++)
    {
      trans[j][i]=a[i][j]; // Calculating Transpose
    }
  }
}

void MatrixMultiply(float a[30][30], float b[30][30],float mult[30][30], int row1, int col1, int row2, int col2) // Matrix Multiply Function
{
for(int i = 0; i < row1; ++i)
    for(int j = 0; j < col2; ++j)
      {
          mult[i][j]=0; // Setting elements initially to zero
      }

for(int i = 0; i < row1; ++i)
    for(int j = 0; j < col2; ++j)
        for(int k = 0; k < col1; ++k)
        {
            mult[i][j] += a[i][k] * b[k][j]; // Matrix multiplication
        }
}

#endif // FUNCTIONS_H_INCLUDED
