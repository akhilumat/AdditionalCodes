#include <iostream>
#include<string>
#include "Functions.h"
using namespace std;

int main()
{   string Function;
    cout << "Action to be performed" << endl;
    cout << "Press T for Transpose" << endl;
    cout << "Press M for Matrix Multiplication" << endl; //Taking Input for action
    cin>> Function;

    while(Function!="T" && Function!="M") // Checking if entry in either T or M
      {
        cout << "Error - Enter either T or M (Case sensitive)"<<endl;
        cout << "Press T for Transpose" << endl;
        cout << "Press M for Matrix Multiplication" << endl;
        cin>> Function;
      }

    if(Function == "T") //If transpose is required
      {
        int rows,cols;
        cout << "Enter rows and columns of matrix (values greater than 0): ";
        cin >> rows >> cols;

        while(rows==0 || cols==0) // checking if rows and cols are zero
          {
          cout << "Size of matrix cant be zero"<<endl;
          cout << "Enter rows and columns of matrix (values greater than 0): "<<endl;
          cin >> rows >> cols;
          }

        cout << endl << "Enter elements of matrix: " << endl;
        float a[30][30], trans[30][30];

        for(int i = 0; i < rows; ++i)
          for(int j = 0; j < cols; ++j) //Input to Matrix
            {
                cout << "Enter elements of Matrix" <<"["<<i + 1 <<","<<j + 1 << "] :";
                cin >> a[i][j];
            }

        cout << endl << "Matrix Entered: " << endl;

        for(int i = 0; i < rows; ++i) //showing the matrix entered
            for(int j = 0; j < cols; ++j)
              {
                  cout << "   " << a[i][j];
                  if(j == cols - 1)
                      cout << endl << endl;
              }

      Transpose(a,trans,rows,cols); // getting Transpose using a function
      cout << endl << "Transpose of Matrix: " << endl;

      for(int i = 0; i < cols; ++i) // outputting the transposed matrix
          for(int j = 0; j < rows; ++j)
            {
                cout << "   " << trans[i][j];
                if(j == rows - 1)
                    cout << endl << endl;
            }
      }

    else if(Function == "M") //If Matrix Multiplication is required
      {
        float a[30][30], b[30][30], mult[30][30];
        int row1,col1,row2,col2;
        cout << "Enter rows and columns for first matrix: "<<endl;
        cin >> row1 >> col1;
        cout << "Enter rows and columns for second matrix: "<<endl;
        cin >> row2 >> col2;
        while(row1==0 || col1==0 || row2==0 || col2==0 ) // checking if rows or columns of the matrices are zero
          {
          cout << "Size of matrix cant be zero"<<endl;
          cout << "Enter rows and columns for first matrix: "<<endl;
          cin >> row1 >> col1;
          cout << "Enter rows and columns for second matrix: "<<endl;
          cin >> row2 >> col2;
          }

        while (col1!=row2) // Checking for 1st Matrix columns equal to rows of 2nd
          {
              cout << "Error!!! Column of first matrix not equal to row of second."<< endl;
              cout << "Enter rows and columns for first matrix: "<<endl;
              cin >> row1 >> col1;
              cout << "Enter rows and columns for second matrix: "<<endl;
              cin >> row2 >> col2;
          }

        cout << endl << "Enter elements of matrix 1:" << endl;

        for(int i = 0; i < row1; ++i) // Taking input for 1st Matrix
            for(int j = 0; j < col1; ++j)
              {
                  cout << "Enter element of first Matrix[" << i + 1<<","<< j + 1 << "] : ";
                  cin >> a[i][j];
              }

        cout << endl << "Enter elements of matrix 2:" << endl;

        for(int i = 0; i < row2; ++i)
            for(int j = 0; j < col2; ++j) // Taking input for 2nd Matrix
              {
                  cout << "Enter element of second Matrix[" << i + 1<<","<< j + 1 << "] : ";
                  cin >> b[i][j];
              }

        MatrixMultiply(a,b,mult,row1,col1,row2,col2);// Matrix Multiplication using a function
        cout << endl << "Matrix 1: " << endl;

        for(int i = 0; i < row1; ++i) // Printing the matrix1
          for(int j = 0; j < col1; ++j)
            {
                cout << "  " << a[i][j];
                if(j == col1-1)
                    cout << endl;
            }
        cout << endl << "Matrix 2: " << endl;

        for(int i = 0; i < row2; ++i) // Printing the matrix2
            for(int j = 0; j < col2; ++j)
              {
                  cout << "  " << b[i][j];
                  if(j == col2-1)
                      cout << endl;
              }
        cout << endl << "Output Matrix after Multiplication: " << endl;

        for(int i = 0; i < row1; ++i) // Printing the output matrix
          for(int j = 0; j < col2; ++j)
            {
                cout << "  " << mult[i][j];
                if(j == col2-1)
                    cout << endl;
            }
        }
  return 0;
}
