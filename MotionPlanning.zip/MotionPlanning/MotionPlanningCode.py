import math
import random

def optimal_search(world_state, robot_pose, goal_pose): # Fuction for optimal search
    delta = [[-1, 0], # go up
             [ 0,-1], # go left
             [ 1, 0], # go down
             [ 0, 1]] # go right    
    A = [[0 for row in range(len(world_state[0]))] for col in range(len(world_state))]
    B = [[-1 for row in range(len(world_state[0]))] for col in range(len(world_state))] # two grids defined same as world state    
    A[robot_pose[0]][robot_pose[1]]=1 # Closing the initial state     
    g = 0
    x = robot_pose[0]
    y = robot_pose[1] # defining initial element of open with cost 0 and initial robot pose    
    open = [[g,x,y]]    
    resign = False # resign becomes true when open list becomes empty (means robot cant open more grid cells to go)
    found = False # found becomes true when goal is reached
    
    while not found and not resign:
        if len(open)==0: # if we reach dead end and path cant be found
            return 'fail', 'No Path'
            resign = True
        else:
            open.sort() 
            open.reverse()
            current = open.pop() # Sorting, reversing and then popping to get the grid cell with minimum cost
            x = current[1]
            y = current[2]
            g = current[0] # getting the elements of grid with minimum cost
            if x==goal_pose[0] and y==goal_pose[1]: # if goal is reached found is true
                found = True
            else:
                for i in range(len(delta)): # taking all the next movements
                    x2 = x + delta[i][0]
                    y2 = y + delta[i][1]
                    if x2>=0 and x2<len(world_state) and y2>=0 and y2<len(world_state[0]): # if next grid cell is in the world state
                        if A[x2][y2] == 0 and world_state[x2][y2] == 0: # if its neither closed or blockage
                            g2=g+1
                            open.append([g2,x2,y2]) #Adding to the cost of the grid cell and then appending to open list 
                            A[x2][y2]=1 # closing the grid cell
                            B[x2][y2] = i # storing the direction to reach the grid cell
    
    x= goal_pose[0]
    y = goal_pose[1]
    path = []
    path.append((x,y)) # appending the final goal position to path
    path_symbols = [[' ' for col in range(len(world_state[0]))] for row in range(len(world_state))] # Generating grid for path symbols
    path_symbols[x][y]='*' # Goal
    delta_name = ['^', '<', 'v', '>'] # Symbols for movements

    while x!=robot_pose[0] or y!=robot_pose[1]: # moving backwards to find the optimum path
        x2 = x-delta[B[x][y]][0]
        y2 = y-delta[B[x][y]][1] # Going back to grid cells from where we came to current grid cell using B values 
        path_symbols[x2][y2]= delta_name[B[x][y]] # Giving symbol of going to next state
        path.append((x2,y2)) # Appending to the path
        x=x2
        y =y2
   
    path.reverse() # reversing the order to get points from start to finish
    return path, path_symbols

def Random_search(world_state, robot_pose, goal_pose): # function for random search
    max_step_number = 100 # setting max steps for search equal to 100
    path = [] 
    delta = [[-1, 0], # go up
             [ 0,-1], # go left
             [ 1, 0], # go down
             [ 0, 1]] # go right
    root = math.floor(max_step_number**0.5) # Steps after which grid can be selected Again
    A = [[0 for row in range(len(world_state[0]))] for col in range(len(world_state))] # Defining grid same as world state
    g = root
    x = robot_pose[0]
    y = robot_pose[1] # setting initial values and appending to open list. Cost set equal to root
    open = [[g,x,y]] 
    resign = False # resign becomes true when open list becomes empty (means robot cant open more grid cells to go)
    found = False # found becomes true when goal is reached
    
    while not found and not resign and max_step_number!=0:
        max_step_number -= 1 # Running for maximum steps defined
        if len(open)==0: # if we reach dead end and path cant be found
            return 'fail'
            resign = True 
        else:
            zeros = [] # Storing grid cells which has not been reached by robot and have first term 0
            nonzeros =[] # Grid cells which were earlier occupied by robot            
            for i in range(len(open)): # Separating opened grid cells from non opened or which were opened max_step_number**0.5 steps early
                if open[i][0]==0:
                    zeros.append(open[i])
                else:
                    nonzeros.append(open[i])
            
            if len(zeros)>0:# checking if grid cells with 0 cost are there
                current = random.choice(zeros) # Making random choice from 0 cost grid cells
            else:
                nonzeros.sort()
                nonzeros.reverse()
                current = nonzeros[-1] # if no zero cost grid cells, grid cell with minimum cost will be selected since it was occupied earliest by robot
            
            x = current[1] 
            y = current[2]
            
            if len(path)>0:
                for i in range(len(path)):
                    A[path[i][0]][path[i][1]] -= 1 # Reducing cost of all path elements by 1 on each step. Since it will become 0 after max_step_number**0.5 steps, and can be selected again
            
            path.append((x,y)) # appending current position to the path
            A[x][y] = root # Setting cost of appended grid cell equal to max_step_number**0.5 steps.
            
            if x==goal_pose[0] and y==goal_pose[1]: # if goal is reached found is true
                found = True
            else:
                open = [] # Emptying the open set
                for i in range(len(delta)): 
                    x2 = x + delta[i][0]
                    y2 = y + delta[i][1] # Checking for all movements
                    if x2>=0 and x2<len(world_state) and y2>=0 and y2<len(world_state[0]): # Checking if the new grid is inside the world
                        if world_state[x2][y2] == 0: # Selecting 0 grid cells
                            if A[x2][y2] < 0:
                                A[x2][y2] = 0 # setting value of cost to zero if it becomes negative since we are subtracting 1 from cost each time next step is taken
                            g = A[x2][y2] # setting cost equal to A grid's values
                            open.append([g,x2,y2]) # Appending to open list
    
    if path[-1][0]==goal_pose[0] and path[-1][1]==goal_pose[1]:  # Checking if goal reached      
        return path
    else:
        return 'fail'
    
world_state =  [[0, 0, 1, 0, 0, 0],
                [0, 0, 1, 0, 0, 0],
                [0, 0, 0, 0, 1, 0],
                [0, 0, 1, 1, 1, 0],
                [0, 0, 0, 0, 1, 0],
                [0, 0, 0, 0, 0, 0]]

print 'Enter Robot pose ( Its initial x and y value for example 2,0 )' 
robot_pose = tuple(int(x.strip()) for x in raw_input().split(',')) # taking robot pose input from user
print 'Enter Goal pose ( x and y value of goal to reach for example 5,5 )'
goal_pose = tuple(int(x.strip()) for x in raw_input().split(',')) # taking gole pose input from user
path, Shortest_path_symbols = optimal_search(world_state, robot_pose, goal_pose) # Optimal path
path2 = Random_search(world_state, robot_pose, goal_pose) # Random search path
print ('')
print ('Optimal Planner Path')
print (path)
print ('')
for i in range(len(Shortest_path_symbols)): # Printing grid with path symbols
    print (Shortest_path_symbols[i])

print ('')
print ('Random Planner Path')
print (path2)